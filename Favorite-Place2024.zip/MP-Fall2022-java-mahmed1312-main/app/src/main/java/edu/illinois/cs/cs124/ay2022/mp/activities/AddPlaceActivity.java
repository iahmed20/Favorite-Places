package edu.illinois.cs.cs124.ay2022.mp.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import java.util.function.Consumer;
import edu.illinois.cs.cs124.ay2022.mp.R;
import edu.illinois.cs.cs124.ay2022.mp.application.FavoritePlacesApplication;
import edu.illinois.cs.cs124.ay2022.mp.models.Place;
import edu.illinois.cs.cs124.ay2022.mp.models.ResultMightThrow;



public class AddPlaceActivity extends AppCompatActivity implements Consumer<ResultMightThrow<Boolean>> {
  @Override
  protected void onCreate(@Nullable final Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    // Load the layout for this activity and set the title
    setContentView(R.layout.activity_addplace);
    Intent backToMap = new Intent(this, MainActivity.class);


    String lat;
    String lon;
    if (savedInstanceState == null) {
      Bundle extras = getIntent().getExtras();
      if (extras == null) {
        lat = null;
        lon = null;
      } else {
        lat  = extras.getString("latitude");
        lon = extras.getString("longitude");
      }
    } else {
      lat = (String) savedInstanceState.getSerializable("latitude");
      lon = (String) savedInstanceState.getSerializable("longitude");
    }

    assert lat != null;
    double lat1 = Double.parseDouble(lat);

    assert lon != null;
    double lon1 = Double.parseDouble(lon);

    Button saveButton = findViewById(R.id.save_button); //FIND A WAY TO GET DESCRIPTION
    saveButton.setOnClickListener(v -> {
      View d1 = findViewById(R.id.description);
      String desc = ((TextView) d1).getText().toString();
      Place p = new Place("fb385634-66c5-486c-b8bc-6c0b22cb77c2", "cum", lat1, lon1, desc);
      //fb385634-66c5-486c-b8bc-6c0b22cb77c2
      FavoritePlacesApplication application = (FavoritePlacesApplication) getApplication();
      application.getClient().postFavoritePlace(p, this);
      startActivity(backToMap);
    });

    Button cancelButton = findViewById(R.id.cancel_button); //FIND A WAY TO GET DESCRIPTION
    cancelButton.setOnClickListener(v -> {
      //View d1 = findViewById(R.id.description);
      startActivity(backToMap);
    });

  }

  @Override
  public void accept(final ResultMightThrow<Boolean> booleanResultMightThrow) {

  }
}
